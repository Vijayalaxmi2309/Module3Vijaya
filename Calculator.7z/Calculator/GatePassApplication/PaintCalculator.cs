﻿using System;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace GatePassApplication
{
    class PaintCalculator
    {
        public static void Run()
        {
            Console.BackgroundColor = ConsoleColor.Yellow;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.Clear();

            Console.WriteLine("======= Geometry Design's Paint Calculator =======\n");
            Console.WriteLine("We've got paint for all your shape needs.");
            Console.WriteLine("What kind of shape do you need us to paint? We currently support: circle, rectangle or triangle.");
            Console.Write("Enter a shape: ");
            string choice = Console.ReadLine().ToLower();
            double area = 0;
            Console.WriteLine();

            if (choice == "circle")
            {
                Console.WriteLine("Great - we'll need some circle measurements first.");
                Circle.DrawDiagram();
                Console.Write("What's the radius of the circle (in feet): ");
                string radiusAnswer = Console.ReadLine();
                double radius = Convert.ToDouble(radiusAnswer);
                // We can also do the above two lines in a single line:
                //  double radius = Convert.ToDouble(ReadLine());
                Circle myCircle = new Circle(radius);
                area = myCircle.GetArea();
            }
            else if (choice == "rectangle")
            {
                Console.WriteLine("Great - we'll need some rectangle measurements first.");
                Rectangle.DrawDiagram();
                Console.Write("What's the width (in feet): ");
                double width = Convert.ToDouble(Console.ReadLine());
                Console.Write("What's the height (in feet): ");
                double height = Convert.ToDouble(Console.ReadLine());
                Rectangle rect = new Rectangle(width, height);
                area = rect.GetArea();
            }
            else if (choice == "triangle")
            {
                Console.WriteLine("Great - we'll need some triangle measurements first.");
                Triangle.DrawDiagram();
                Console.Write("What's the base width (in feet): ");
                double width = Convert.ToDouble(Console.ReadLine());
                Console.Write("What's the height (in feet): ");
                double height = Convert.ToDouble(Console.ReadLine());
                Triangle tri = new Triangle(width, height);
                area = tri.GetArea();
            }
            else
            {
                Console.WriteLine("You've choosen a shape we don't support yet!");
                Console.WriteLine("Press any key to restart");
                Console.ReadKey();
                Run();
                return;
            }

            double costPerSquareFoot = 3.5;
            double totalCost = area * costPerSquareFoot;
            Console.WriteLine("The area of the shape is: " + Math.Round(area, 2));
            Console.WriteLine("The total cost is: " + totalCost.ToString("C"));

            Console.WriteLine("\n\n\nThanks for using the calculator. Press any key to exit.");
            Console.ReadKey();
        }
    }
}




        
    

